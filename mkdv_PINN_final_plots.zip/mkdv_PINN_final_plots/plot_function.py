#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt 
import matplotlib as mpl
from scipy.interpolate import griddata
import matplotlib.transforms as mtransforms
import os, sys
from statistics import mean 

# In[2]:


def griding (dat, ind, X, T) :
    u = griddata (dat[:, 0:2], dat[:, ind], (X, T), method = "cubic")
    return u


# In[3]:


def plotting (dat1, ax_label, abc_position, cm, cmap_label, err_val_dec, savefile) :
    tmin, tmax = min(dat1[:, 1]), max(dat1[:, 1])
    xmin, xmax = min(dat1[:, 0]), max(dat1[:, 0])

    t = np.linspace (tmin, tmax, 400)
    x = np.linspace(xmin, xmax, 520)
    X, T = np.meshgrid (x, t)
    ext1 = ([tmin, tmax, xmin, xmax])

    x2 = np.array ([[t1, 0] for t1 in x])
    x3 = np.array ([[xmin, t1] for t1 in t])
    x4 = np.array ([[xmax, t1] for t1 in t])


    idx = np.random.randint (0, len(x3), 50)
    idy = np.random.randint (0, len(x2), 20)

    l2 = x2[idy, :]
    l3 = x3[idx, :]
    l4 = x4[idx, :]
    
    r11 = griding (dat1, 2, X, T)
    p11 = griding (dat1, 3, X, T)
    
    fig, axs = plt.subplots(3,3, figsize = (18, 14),constrained_layout = True,)
    trans = mtransforms.ScaledTranslation(10/72, -5/72, fig.dpi_scale_trans)

    fs = [3, 3]
    it = [100, 260, 400]
    pl1 = [p11.T, r11.T, (p11 - r11).T**2]
    pl2 = [p11.T[it[0]], p11.T[it[1]], p11.T[it[2]]]
    pl3 = [r11.T[it[0]], r11.T[it[1]], r11.T[it[2]]]
    e1 = ((p11 - r11)**2).flatten()
    error = mean(e1[~np.isnan(e1)])
    print ("error value = ",error)

    tix = [0.3, 0.3, 0.4]
    tiy = [1.1, 1.1, 1.1]

    ti1 = [np.round(np.linspace (min(pl1[0].flatten()), max(pl1[0].flatten()), 3), 1), 
           np.round(np.linspace (min(pl1[1].flatten()), max(pl1[1].flatten()), 3), 1),
           np.round(np.linspace (min(pl1[2].flatten()), max(pl1[2].flatten()), 3), err_val_dec)]

    ti2 = [[0, 3, 6], 
           [-2, 0, 2],
           [-6, -3, 0]]

    v1 = [np.round(max(p11.flatten()), 1), np.round(max(pl1[1].flatten()), 1),
          np.round(max(pl1[2].flatten()), err_val_dec)]
    pa = [0.05, 0.05, -0.18]
    title = ["Exact", "Predicted", "Error"]
    lw1 = 3
    label = ["($a$)", "($b$)", "($c$)", "($d$)", "($e$)", "($f$)", "($g$)", "($h$)", "($i$)"]
    la = 0
    xa, ya = abc_position
    
    for i in range (fs[0]) :
        for j in range (fs[1])  :
            axs[i, j].text (xa, ya, label[la], color = "black", transform=axs[i, j].transAxes + trans,)
            if i == 0 :
                axs[i, j].set_xticks(np.linspace (tmin, tmax, 3))
                axs[i, j].set_yticks(np.linspace (xmin, xmax, 3))
                ca = axs[i, j].imshow (pl1[j], cmap = cm, aspect = "auto", extent = ext1, vmax = v1[j])
                cla = plt.colorbar (ca, ax = axs[i, j], ticks = ti1[j], pad = pa[j])
                cla.formatter.set_powerlimits ((0,0))
                axs[i, j].text(tix[j], tiy[j], title[j], color = "black", 
                                     transform=axs[i, j].transAxes + trans, 
                                     backgroundcolor = "c")
                axs[i, j].set_xlabel(ax_label[i][0])
                if j == 2 :
                    axs[i, j].text (xa, ya, label[la], color = "w", transform=axs[i, j].transAxes + trans,)
                if j < 2 :
                    cla.ax.set_title (cmap_label)
                    axs[i, j].axhline (x[it[0]], tmin, tmax, c = 'w', ls = '--')
                    axs[i, j].axhline (x[it[1]], tmin, tmax, c = 'w', ls = '--')
                    axs[i, j].axhline (x[it[2]], tmin, tmax, c = 'w', ls = '--')
                if j == 0 :
                    axs[i, j].plot (l3[:, 1], l3[:, 0], color = 'black', ls = '-', marker = '*', lw = 1)
                    axs[i, j].plot (l4[:, 1], l4[:, 0], color = 'black', ls = '-', marker = '*', lw = 1)
                    axs[i, j].plot (l2[:, 1], l2[:, 0], color = 'black', ls = '-', marker = '*', lw = 1)
                    axs[i, j].set_ylabel(ax_label[i][1])

            elif i == 1 :
                if j == 0 :
                    axs[i, j].plot (t, pl3[j], 'r', lw = lw1, label = "Analytical")            
                    axs[i, j].plot (t, pl2[j], 'b--', lw = lw1, label = "Predicted")
                    axs[i, j].set_ylabel(ax_label[i][1])
                axs[i, j].plot (t, pl3[j], 'r', lw = lw1)            
                axs[i, j].plot (t, pl2[j], 'b--', lw = lw1)
                axs[i, j].set_yticks(np.round(np.linspace(np.min(pl3[j]), np.max(pl3[j]), 3), 2))
                axs[i, j].set_title ("$x = %.2f$"%(x[it[j]]))
                axs[i, j].set_xlabel(ax_label[i][0])
            elif i == 2 :
                axs[i, j].plot (pl2[j], pl2[j],'k', lw = lw1)           
                axs[i, j].plot (pl3[j], pl2[j],'c.', lw = lw1)           
                axs[i, j].set_xlabel(ax_label[i][0])
                axs[i, j].set_yticks(np.round(np.linspace(np.min(pl3[j]), np.max(pl3[j]), 3), 2))
                axs[i, j].set_xticks(np.round(np.linspace(np.min(pl3[j]), np.max(pl3[j]), 3), 2))

                if j == 0 :
                    axs[i, j].plot (pl2[j], pl2[j],'k', lw = lw1, label = "True Value")           
                    axs[i, j].plot (pl3[j], pl2[j],'c.', lw = lw1,label = "Predicted Value")           
                    axs[i, j].set_ylabel(ax_label[i][1])
            la += 1
    lines_labels = [ax.get_legend_handles_labels() for ax in fig.axes]
    lines, labels = [sum(lol, []) for lol in zip(*lines_labels)]
    lgd = fig.legend(lines, labels,bbox_to_anchor=(0.31, -0.081),  ncol = 4, fontsize =20,
                loc="lower left", fancybox=True, shadow=True)  
    
    plt.savefig(savefile+'.jpg', bbox_inches='tight', dpi = 300)
    plt.savefig(savefile+'.png', bbox_inches='tight', dpi = 300)
    plt.savefig(savefile+'.eps', bbox_inches='tight', dpi = 300)
    plt.savefig(savefile+'.pdf', bbox_inches='tight', dpi = 300)
    return fig


# In[ ]:




